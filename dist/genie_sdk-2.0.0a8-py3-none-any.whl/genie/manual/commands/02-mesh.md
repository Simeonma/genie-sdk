# 02 · f.mesh — grid & local refinement

> Nominal grid spacing (dx/dy/dz), box-shaped refinement regions (`refine`),
> and two global grid guards. All SI.

![Mesh refinement](figs/fig-mesh.svg)

## `f.mesh` properties

| Property | Type / unit | Description |
|---|---|---|
| `dx` / `dy` / `dz` | m, > 0 | Nominal spacing per axis; unset `dy`/`dz` fall back to `dx`, so setting `dx` alone suffices for a uniform grid |
| `max_refinement` | int ≥ 1, default 128 | Maximum recursion depth of refine regions; leave alone in general |
| `min_cells` | int ≥ 1, default 10 | Minimum cell count per domain axis; a 422 mentioning "min_cells" means domain/spacing ratio is unbalanced |

```python
f.mesh.dx = 25e-9              # same spacing on all axes
f.mesh.dx, f.mesh.dy, f.mesh.dz = 15e-9, 30e-9, 30e-9   # independent per axis
```

**Common pitfalls**

- Giving `dx` in nm (e.g. `dx = 25`) makes the domain orders of magnitude smaller than the grid — min_cells rejects it or the cell count explodes. The whole SDK is SI.
- `max_refinement`/`min_cells` are int slots: passing a float (even `10.0`) is rejected with `TypeError`.

## `f.mesh.refine()`

Refine the grid inside a box; stackable (one refinement region per call).
Returns: `Mesh` (itself — chain more `refine` calls or write properties).

| Param | Type | Required | Default | Description |
|---|---|---|---|---|
| `x_range` | (lo, hi) | Yes | — | Region extent (m) |
| `y_range` | (lo, hi) | Yes | — | Same as above |
| `z_range` | (lo, hi) | Yes | — | Same as above |
| `factor` | int / [fx, fy, fz] / str | Yes | — | Refinement factor: int ≥ 2 (all axes) / per-axis 3-list / expression string (evaluated server-side); omitted → `ValueError`, no silent default |
| `growth_rate` | float | No | 1.2 | Transition ratio between adjacent spacings (≥ 1.0); not serialized at the default |

**Example**

```python
f.mesh.refine((-0.5e-6, 0.5e-6), (-0.5e-6, 0.5e-6), (0, 0.3e-6), factor=2)
f.mesh.refine(x_range=(-2e-6, -1e-6), y_range=(-1e-6, 1e-6),
              z_range=(-1e-6, 1e-6), factor=[2, 2, 4])
```

**Common pitfalls**

- `factor` has integer semantics — list elements are `int()`-truncated, so `1.5` becomes 1 (no refinement at all); pass integers ≥ 2, prefer the all-keyword form.
- Don't place a region flush against the domain edge: refining inside the PML wastes cells and may trip the gradient guard; enclose the structure with 2–3 transition layers.

## `f.mesh.clear_refinements()`

Clears all refinement regions; `dx/dy/dz` and the global guards are untouched.
